export class Config {
    // static Host = "https://mccc.wdipl.com/";
    // static BasePath = "https://mccc.wdipl.com/backend2/api"; 
    static Host = "https://www.mcccapp.in/";
    static BasePath = "https://www.mcccapp.in/backend2/api"; 
    static AfterLogin = "/home";   
}

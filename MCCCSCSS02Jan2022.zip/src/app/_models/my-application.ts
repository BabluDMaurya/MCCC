export interface MyApplication {
    title: string | undefined;
    short_discription : string | undefined;
    confirm : any | undefined;
    id:any | undefined;
}
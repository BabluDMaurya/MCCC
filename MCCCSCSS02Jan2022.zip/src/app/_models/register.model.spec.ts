import { Register } from './register.model';

describe('Register', () => {
  it('should create an instance', () => {
    expect(new Register()).toBeTruthy();
  });
});

export class User {
    token: string | undefined;
    profileStatus : string | undefined;
    userDetails : any | undefined;
    status :any;
    percentage :any;
}
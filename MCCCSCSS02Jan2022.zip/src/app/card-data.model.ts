export interface CardData {
    imageId: string;
    state: 'default' | 'flipped' | 'matched';
}

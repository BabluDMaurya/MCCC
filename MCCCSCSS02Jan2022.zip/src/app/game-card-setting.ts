export const BOARD_WIDTH = 2; // should be 8 max or increase container max-width in app.component.css if you want a wider board
export const BOARD_HEIGHT = 2;